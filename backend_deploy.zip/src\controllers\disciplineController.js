const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const getCategories = async (req, res) => {
    try {
        const sql = `SELECT * FROM behaviour_categories ORDER BY type, name;`;
        const result = await pool.query(sql);
        res.json(result.rows);
    } catch (err) {
        console.error('Error fetching categories:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

const createRecord = async (req, res) => {
    try {
        const { studentId, categoryId, note, date } = req.body;

        if (!studentId || !categoryId) {
            return res.status(400).json({ error: 'Student ID and Category ID are required' });
        }

        // Issuer Logic: Ideally from JWT (req.user.id). 
        // For now, we'll pick the first usage 'staff' user or null if none found, 
        // OR just hardcode a UUID if we seeded one.
        // Let's fetch a staff member dynamically to avoid FK errors.
        const staffRes = await pool.query("SELECT id FROM profiles WHERE role = 'staff' LIMIT 1");
        const issuerId = staffRes.rows.length > 0 ? staffRes.rows[0].id : null;

        if (!issuerId) {
            // Fallback: If no staff exists, we can't properly record issuer. 
            // But for this phase, let's just use the student themselves as issuer just to make it pass FK? 
            // No, that's bad. We'll handle this in seeding.
            console.warn("No staff found for issuer_id");
        }

        // Fetch tenant_id from student? Or just hardcode
        const studentRes = await pool.query("SELECT tenant_id FROM profiles WHERE id = $1", [studentId]);
        if (studentRes.rows.length === 0) return res.status(404).json({ error: 'Student not found' });
        const tenantId = studentRes.rows[0].tenant_id;

        const sql = `
            INSERT INTO behaviour_records 
            (tenant_id, student_id, issuer_id, category_id, description, incident_date, status)
            VALUES ($1, $2, $3, $4, $5, $6, 'recorded')
            RETURNING *;
        `;

        const values = [tenantId, studentId, issuerId, categoryId, note, date || new Date()];
        const result = await pool.query(sql, values);

        res.status(201).json(result.rows[0]);

    } catch (err) {
        console.error('Error creating discipline record:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { getCategories, createRecord };
