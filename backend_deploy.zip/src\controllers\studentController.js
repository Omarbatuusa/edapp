const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const searchStudents = async (req, res) => {
    try {
        const { query } = req.query;
        // Tenant ID should ideally come from Auth Middleware (JWT).
        // For now, we'll hardcode or fetch the first one for the "STMARKS" school if not provided.
        // In a real app, req.user.tenantId would be used.

        if (!query) {
            return res.status(400).json({ error: 'Query parameter is required' });
        }

        const sql = `
            SELECT id, first_name, last_name, email 
            FROM profiles 
            WHERE role = 'student' 
            AND (first_name ILIKE $1 OR last_name ILIKE $1)
            LIMIT 10;
        `;

        const values = [`%${query}%`];
        const result = await pool.query(sql, values);

        res.json(result.rows);
    } catch (err) {
        console.error('Error searching students:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { searchStudents };
