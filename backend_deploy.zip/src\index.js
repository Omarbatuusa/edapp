require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('dev'));
app.use(express.json());

// Database Connection
const { Pool } = require('pg');
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
});

// Routes
const studentRoutes = require('./routes/students');
const policyRoutes = require('./routes/policies');
const disciplineRoutes = require('./routes/discipline');
const authRoutes = require('./routes/auth');

// Safe load of Tenant routes to prevent crash if module fails
try {
    const tenantRoutes = require('./routes/tenants');
    app.use('/v1/tenants', tenantRoutes);
    console.log('Tenant routes loaded successfully');
} catch (err) {
    console.error('Failed to load Tenant Routes:', err);
}

app.use('/v1/students', studentRoutes);
app.use('/v1/policies', policyRoutes);
app.use('/v1/discipline', disciplineRoutes);
try {
    app.use('/v1/behaviour', require('./routes/behaviour'));
} catch (err) {
    console.error('Failed to load Behaviour Routes:', err);
}
app.use('/v1/auth', authRoutes);
app.use('/v1/rbac', require('./routes/rbac'));
app.use('/v1/academic', require('./routes/academic'));
app.use('/v1/gamification', require('./routes/gamification'));
app.use('/v1/educator', require('./routes/educator'));


// Init Database Schema (Temporary Helper for Local Dev)
app.post('/v1/admin/init-db', async (req, res) => {
    try {
        const fs = require('fs');
        const path = require('path');
        const schemaPath = path.join(__dirname, '../db/schema_v2.sql');
        const schemaSql = fs.readFileSync(schemaPath, 'utf8');

        await pool.query(schemaSql);
        res.json({ status: 'ok', message: 'Database schema initialized' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// Seed Integration Data (Phase 5)
app.post('/v1/admin/seed-integration', async (req, res) => {
    try {
        const fs = require('fs');
        const path = require('path');
        const seedPath = path.join(__dirname, '../db/seed_integration.sql');
        const seedSql = fs.readFileSync(seedPath, 'utf8');

        await pool.query(seedSql);
        res.json({ status: 'ok', message: 'Integration data seeded successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// Seed Data (Temporary Helper)
app.post('/v1/admin/seed', async (req, res) => {
    try {
        // 1. Create Tenant
        let tenantId;
        try {
            const tenantRes = await pool.query(`
                INSERT INTO tenants (name, code, domain) 
                VALUES ('St. Marks High', 'STMARKS', 'stmarks.edapp.co.za') 
                RETURNING id;
            `);
            tenantId = tenantRes.rows[0].id;
        } catch (e) {
            // Assume it exists or conflict occurred
            const fetchRes = await pool.query("SELECT id FROM tenants WHERE code = 'STMARKS'");
            if (fetchRes.rows.length > 0) {
                tenantId = fetchRes.rows[0].id;
            } else {
                throw e; // Re-throw if it wasn't a conflict we can recover from
            }
        }

        // 2. Create Staff (Issuer)
        let staffId;
        const staffEmail = 'admin@stmarks.edu';
        try {
            const staffRes = await pool.query(`SELECT id FROM profiles WHERE email = $1`, [staffEmail]);
            if (staffRes.rows.length > 0) {
                staffId = staffRes.rows[0].id;
            } else {
                const insertRes = await pool.query(`
                INSERT INTO profiles (email, first_name, last_name, role, tenant_id)
                VALUES ($1, 'Admin', 'User', 'staff', $2)
                RETURNING id;
            `, [staffEmail, tenantId]);
                staffId = insertRes.rows[0].id;
            }
        } catch (e) { console.error('Staff seed error', e); }

        // 3. Create Students
        const students = [
            ['john.doe@stmarks.edu', 'John', 'Doe'],
            ['jane.smith@stmarks.edu', 'Jane', 'Smith'],
            ['mike.jones@stmarks.edu', 'Michael', 'Jones']
        ];

        for (const s of students) {
            try {
                const check = await pool.query("SELECT id FROM profiles WHERE email = $1", [s[0]]);
                if (check.rows.length === 0) {
                    await pool.query(`
                    INSERT INTO profiles (email, first_name, last_name, role, tenant_id)
                    VALUES ($1, $2, $3, 'student', $4);
                `, [s[0], s[1], s[2], tenantId]);
                }
            } catch (e) { console.error('Student seed error', e); }
        }

        // 4. Create Categories
        const categories = [
            ['Late Coming', 'demerit', 1, 'Level 1'],
            ['Uniform Violation', 'demerit', 1, 'Level 1'],
            ['Outstanding Citizenship', 'merit', 5, 'Level 1'],
            ['Homework Not Done', 'demerit', 2, 'Level 1']
        ];

        for (const c of categories) {
            try {
                const check = await pool.query("SELECT id FROM behaviour_categories WHERE name = $1 AND tenant_id = $2", [c[0], tenantId]);
                if (check.rows.length === 0) {
                    await pool.query(`
                    INSERT INTO behaviour_categories (name, type, points, severity_level, tenant_id)
                    VALUES ($1, $2, $3, $4, $5);
                `, [c[0], c[1], c[2], c[3], tenantId]);
                }
            } catch (e) { console.error('Category seed error', e); }
        }
        res.json({ status: 'ok', message: 'Data seeded successfully (Tenant, Staff, Students, Categories)' });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`[Backend] Server running on port ${PORT}`);
});
