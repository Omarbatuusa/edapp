const db = require('../config/db');

const academicController = {
    // GET /v1/academic/timetable
    getTimetable: async (req, res) => {
        try {
            // Get current student's class
            const studentId = req.user.id;

            // 1. Get Student Enrollment & Tenant

            const tenantId = req.user.tenantId; // Assumed set by auth middleware

            // 2. Fetch timetable
            // Note: We join classes to filter by tenant if needed, but tenant_id is on timetables now
            const result = await db.query(
                `SELECT 
                    t.start_time as time, 
                    s.name as subject, 
                    t.room, 
                    t.type,
                    CASE 
                        WHEN t.type = 'Core' THEN 'bg-blue-100 text-blue-700'
                        WHEN t.type = 'Language' THEN 'bg-pink-100 text-pink-700'
                        WHEN t.type = 'Elective' THEN 'bg-indigo-100 text-indigo-700'
                        ELSE 'bg-slate-100 text-slate-600'
                    END as color
                 FROM timetables t
                 JOIN subjects s ON t.subject_id = s.id
                 JOIN enrollments e ON t.class_id = e.class_id
                 WHERE e.student_id = $1 AND t.tenant_id = $2
                 ORDER BY t.start_time`,
                [studentId, tenantId]
            );

            // Format times (HH:MM)
            const schedule = result.rows.map(row => ({
                ...row,
                time: row.time.substring(0, 5)
            }));

            res.json({ date: new Date().toISOString(), schedule });
        } catch (err) {
            console.error(err);
            res.status(500).json({ error: 'Server Error' });
        }
    },

    // GET /v1/academic/results
    getResults: async (req, res) => {
        // Mock Data (Phase 5 Part B: Result Schema not yet fully defined in plan, keeping mock for safety or implementing basic)
        // Plan mentioned querying `student_results` but we didn't create that schema yet in `schema_academic.sql`.
        // Let's stick to mock for Results until we create that table, or create a quick one.
        // For now, let's keep Mock to avoid breaking it, as Timetable/Attendance/Assignments were the focus.
        const results = {
            term: "Term 3",
            year: "2025",
            average: 72,
            subjects: [
                { name: "Mathematics", mark: 78, symbol: "B", trend: "up", teacher: "Mr. Dlamini" },
                { name: "Physical Sciences", mark: 65, symbol: "C", trend: "down", teacher: "Ms. Khumalo" },
                { name: "English HL", mark: 82, symbol: "A", trend: "up", teacher: "Mrs. Smith" },
                { name: "Life Orientation", mark: 88, symbol: "A", trend: "steady", teacher: "Coach J" },
                { name: "Geography", mark: 68, symbol: "C", trend: "up", teacher: "Mr. Naidoo" },
                { name: "Zulu FAL", mark: 55, symbol: "D", trend: "steady", teacher: "Mrs. Zondi" },
            ]
        };
        res.json(results);
    },

    // GET /v1/academic/assignments
    getAssignments: async (req, res) => {
        try {
            const studentId = req.user.id;

            // Fetch assignments for student's class OR individual assignments
            // Fetch assignments
            const result = await db.query(
                `SELECT 
                    a.id, 
                    sub.name as subject, 
                    a.title, 
                    a.description, 
                    to_char(a.due_date, 'YYYY-MM-DD') as "dueDate", 
                    a.status, 
                    a.is_urgent as urgent
                 FROM assignments a
                 JOIN class_subjects cs ON a.class_subject_id = cs.id
                 JOIN subjects sub ON cs.subject_id = sub.id
                 JOIN enrollments e ON e.class_id = cs.class_id
                 WHERE e.student_id = $1 AND a.tenant_id = $2 AND a.status = 'Active'`,
                [studentId, req.user.tenantId]
            );

            // If empty, return strict array
            res.json(result.rows);
        } catch (err) {
            console.error(err);
            res.status(500).json({ error: 'Server Error' });
        }
    }
};

module.exports = academicController;
