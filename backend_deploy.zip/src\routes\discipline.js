const express = require('express');
const router = express.Router();
const disciplineController = require('../controllers/disciplineController');

// GET /api/discipline/categories?tenantId=...
router.get('/categories', disciplineController.getCategories);

// POST /api/discipline/issue
router.post('/issue', disciplineController.createRecord);

// GET /api/discipline/history?studentId=...&tenantId=...
// router.get('/history', disciplineController.getStudentHistory);

module.exports = router;
