const { Pool } = require('pg');
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
});

exports.searchTenant = async (req, res) => {
    try {
        const { code, domain } = req.query;

        if (!code && !domain) {
            return res.status(400).json({ error: "Tenant code or domain is required" });
        }

        let query = "SELECT id, name, code, domain, logo_url, config FROM tenants WHERE ";
        let params = [];

        if (code) {
            query += "code = $1";
            params.push(code.toUpperCase());
        } else if (domain) {
            query += "domain = $1";
            params.push(domain.toLowerCase());
        }

        query += " LIMIT 1";

        const result = await pool.query(query, params);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: "Tenant not found" });
        }

        const tenant = result.rows[0];

        // Map DB columns to client interface
        // mockData interface: { id, name, code, logoUrl, themeColor, config }
        // DB: logo_url -> logoUrl
        // Config: pass through

        const responseData = {
            id: tenant.id,
            name: tenant.name,
            code: tenant.code,
            logoUrl: tenant.logo_url,
            domain: tenant.domain,
            // Fallback theme or extract from config if present
            themeColor: tenant.config?.themeColor || "#135bec",
            config: tenant.config || { modules: [] }
        };

        res.json(responseData);
    } catch (err) {
        console.error("Search Tenant Error:", err);
        res.status(500).json({ error: "Internal Server Error" });
    }
};
