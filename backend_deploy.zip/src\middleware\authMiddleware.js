const jwt = require('jsonwebtoken');
const db = require('../config/db');

const verifyToken = async (req, res, next) => {
    const token = req.header('Authorization');

    if (!token) {
        return res.status(401).json({ error: 'Access denied' });
    }

    try {
        const verified = jwt.verify(token.replace('Bearer ', ''), process.env.JWT_SECRET);
        req.user = verified; // Contains { id: '...' }

        // Fetch User's Tenant ID (Primary)
        // In a real multi-tenant app, user might switch tenants, but usually they have a home tenant.
        // We'll fetch the one from 'profiles'.
        const profileRes = await db.query('SELECT tenant_id FROM profiles WHERE id = $1', [req.user.id]);
        if (profileRes.rows.length > 0) {
            req.user.tenantId = profileRes.rows[0].tenant_id;
        }

        // Fetch User's Active Role and Capabilities
        // Simplified: Fetch ALL capabilities from ALL active assignments for now
        // In a real scenario, you might filter by the current "switched" tenant context
        const sql = `
            SELECT DISTINCT c.slug
            FROM user_role_assignments ura
            JOIN roles r ON ura.role_id = r.id
            JOIN role_capabilities rc ON r.id = rc.role_id
            JOIN capabilities c ON rc.capability_id = c.id
            WHERE ura.user_id = $1 AND ura.is_active = true
        `;

        const result = await db.query(sql, [req.user.id]);
        const capabilities = result.rows.map(row => row.slug);

        req.user.capabilities = capabilities;

        next();
    } catch (err) {
        console.error('Initial Token Verify Error:', err);
        // Fallback for demo: If DB fails or dev token, allow basic request but no caps
        if (process.env.NODE_ENV === 'development') {
            req.user = { id: 'dev-user', capabilities: [] };
            return next();
        }
        res.status(400).json({ error: 'Invalid token' });
    }
};

const requireCapability = (capability) => {
    return (req, res, next) => {
        if (!req.user || !req.user.capabilities || !req.user.capabilities.includes(capability)) {
            return res.status(403).json({ error: 'Forbidden: Missing Capability ' + capability });
        }
        next();
    };
};

module.exports = { verifyToken, requireCapability };
