'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Building2, QrCode, Shield } from 'lucide-react'
import { apiClient } from '@/lib/api-client'

export default function TenantDiscoveryPage() {
    const router = useRouter()
    const [schoolCode, setSchoolCode] = useState('')
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')
    const [attempts, setAttempts] = useState(0)

    // Load attempts from localStorage
    useEffect(() => {
        const stored = localStorage.getItem('discovery_attempts')
        if (stored) {
            const data = JSON.parse(stored)
            const now = Date.now()
            // Reset if more than 1 hour old
            if (now - data.timestamp < 3600000) {
                setAttempts(data.count)
            } else {
                localStorage.removeItem('discovery_attempts')
            }
        }
    }, [])

    // Debounced validation
    useEffect(() => {
        if (schoolCode.length >= 3) {
            const timer = setTimeout(() => {
                // Validation logic here
            }, 500)
            return () => clearTimeout(timer)
        }
    }, [schoolCode])

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        // Auto-uppercase
        const value = e.target.value.toUpperCase()
        setSchoolCode(value)
        setError('')
    }

    const handleContinue = async () => {
        if (!schoolCode.trim()) {
            setError('Please enter a school code')
            return
        }

        setLoading(true)
        setError('')

        try {
            // Increment attempts
            const newAttempts = attempts + 1
            setAttempts(newAttempts)
            localStorage.setItem('discovery_attempts', JSON.stringify({
                count: newAttempts,
                timestamp: Date.now()
            }))

            // Validate school code
            const response = await apiClient.get(`/tenants/lookup-by-code?code=${encodeURIComponent(schoolCode)}`)
            const tenant = response.data

            // Store tenant for confirmation
            sessionStorage.setItem('tenant', JSON.stringify(tenant))

            // Redirect to confirmation
            router.push(`/discovery/confirm?slug=${tenant.slug}`)
        } catch (err: any) {
            setError(err.message || 'Invalid school code')
        } finally {
            setLoading(false)
        }
    }

    const handleScanQR = () => {
        router.push('/discovery/scan')
    }

    const handleAdminLogin = () => {
        window.location.href = 'https://admin.edapp.co.za'
    }

    return (
        <div className="app-page">
            <div className="app-container">
                <div className="flex flex-col items-center justify-center min-h-screen py-8">
                    {/* Logo */}
                    <div className="mb-8 text-center">
                        <h1 className="text-4xl font-bold mb-2">EdApp</h1>
                        <p className="text-muted-foreground">Find your school</p>
                    </div>

                    {/* Main Card */}
                    <Card className="w-full max-w-md card-elevated">
                        <CardHeader className="text-center">
                            <CardTitle className="text-2xl">School Discovery</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-6">
                            {/* School Code Input */}
                            <div className="space-y-2">
                                <label className="text-sm font-medium">School Code</label>
                                <Input
                                    type="text"
                                    placeholder="Enter school code"
                                    value={schoolCode}
                                    onChange={handleInputChange}
                                    className="text-center text-lg font-mono uppercase"
                                    maxLength={10}
                                    autoFocus
                                />
                                {error && (
                                    <p className="text-sm text-red-600">{error}</p>
                                )}
                            </div>

                            {/* Continue Button */}
                            <Button
                                onClick={handleContinue}
                                className="w-full btn-outline-effect"
                                size="lg"
                                disabled={loading || schoolCode.length < 2}
                            >
                                {loading ? 'Searching...' : 'Continue'}
                            </Button>

                            {/* Divider */}
                            <div className="relative">
                                <div className="absolute inset-0 flex items-center">
                                    <span className="w-full border-t" />
                                </div>
                                <div className="relative flex justify-center text-xs uppercase">
                                    <span className="bg-background px-2 text-muted-foreground">
                                        Or
                                    </span>
                                </div>
                            </div>

                            {/* QR Code Button */}
                            <Button
                                onClick={handleScanQR}
                                variant="outline"
                                className="w-full"
                                size="lg"
                            >
                                <QrCode className="mr-2 h-5 w-5" />
                                Scan QR Code
                            </Button>
                        </CardContent>
                    </Card>

                    {/* Platform Admin Card */}
                    <Card className="w-full max-w-md mt-4 cursor-pointer hover:border-primary transition-colors" onClick={handleAdminLogin}>
                        <CardContent className="flex items-center justify-between p-4">
                            <div className="flex items-center gap-3">
                                <Shield className="h-5 w-5 text-primary" />
                                <span className="font-medium">Platform Admin</span>
                            </div>
                            <span className="text-sm text-muted-foreground">→</span>
                        </CardContent>
                    </Card>

                    {/* Footer */}
                    <div className="mt-8 text-center text-sm text-muted-foreground space-y-2">
                        <p>EdApp v1.0.0 • Development</p>
                        <div className="flex gap-4 justify-center">
                            <a href="/privacy" className="hover:underline">Privacy Policy</a>
                            <a href="/terms" className="hover:underline">Terms of Service</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
