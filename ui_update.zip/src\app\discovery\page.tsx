"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { apiClient } from "@/lib/api-client"
import { HelpPopup } from "@/components/discovery/help-popup"
import { ThemeToggle } from "@/components/discovery/theme-toggle"

export default function TenantDiscoveryPage() {
    const router = useRouter()
    const [schoolCode, setSchoolCode] = useState("")
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const [showHelp, setShowHelp] = useState(false)

    // Debounced validation logic (optional, for now just cleaning error)
    useEffect(() => {
        if (schoolCode) setError("")
    }, [schoolCode])

    const handleContinue = async () => {
        if (!schoolCode.trim()) {
            setError("Please enter your school code")
            return
        }

        setLoading(true)
        setError("")

        try {
            const response = await apiClient.get(`/tenants/lookup-by-code?code=${encodeURIComponent(schoolCode)}`)
            const tenant = response.data

            // Store tenant for confirmation
            sessionStorage.setItem("tenant", JSON.stringify(tenant))

            // Redirect to confirmation
            router.push(`/discovery/confirm?slug=${tenant.slug}`)
        } catch (err: any) {
            setError(err.response?.data?.message || "School not found. Please check the code.")
        } finally {
            setLoading(false)
        }
    }

    const handleScanQR = () => {
        router.push("/discovery/scan")
    }

    const handleAdminLogin = () => {
        window.location.href = "https://admin.edapp.co.za"
    }

    const appVersion = process.env.NEXT_PUBLIC_APP_VERSION || "v1.0.0"
    const appEnv = process.env.NEXT_PUBLIC_APP_ENV || "Production"
    const currentYear = new Date().getFullYear()

    return (
        <div className="min-h-screen bg-[#f6f7f8] dark:bg-[#101922] text-[#0d141b] dark:text-white flex flex-col font-display transition-colors duration-300">
            {/* Top Navigation */}
            <div className="flex items-center justify-between p-6">
                <button
                    onClick={() => router.back()}
                    className="flex size-10 items-center justify-center rounded-full hover:bg-gray-200 dark:hover:bg-white/10 transition-colors"
                >
                    <span className="material-symbols-outlined">arrow_back_ios_new</span>
                </button>

                <div className="flex items-center gap-2">
                    <ThemeToggle />
                    <button
                        onClick={() => setShowHelp(true)}
                        className="flex size-10 items-center justify-center rounded-full hover:bg-gray-200 dark:hover:bg-white/10 transition-colors"
                    >
                        <span className="material-symbols-outlined">help_outline</span>
                    </button>
                </div>
            </div>

            {/* Main Content */}
            <div className="flex-1 flex flex-col px-8 pt-8 pb-12 w-full max-w-md mx-auto">
                {/* Logo & Title */}
                <div className="flex flex-col items-center mb-10">
                    <div className="w-20 h-20 mb-6 flex items-center justify-center bg-primary rounded-2xl shadow-xl shadow-primary/20">
                        {/* 
                            TODO: Replace with actual Image using next/image when asset is available.
                            Using Material Icon as placeholder per design spec.
                        */}
                        <span className="material-symbols-outlined text-white text-5xl">school</span>
                    </div>
                    <h1 className="text-3xl font-bold tracking-tight text-center mb-3">
                        Find your school
                    </h1>
                    <p className="text-[#4c739a] dark:text-slate-400 text-center text-base leading-relaxed max-w-xs">
                        Enter the unique code provided by your institution to get started
                    </p>
                </div>

                {/* Input Section */}
                <div className="space-y-6 w-full">
                    <div className="space-y-2">
                        <label className="text-sm font-medium ml-1 text-gray-600 dark:text-gray-400">
                            School code
                        </label>
                        <input
                            type="text"
                            value={schoolCode}
                            onChange={(e) => setSchoolCode(e.target.value.toUpperCase())}
                            onKeyDown={(e) => e.key === 'Enter' && handleContinue()}
                            placeholder="e.g. EDAPP-2024"
                            className="w-full h-16 px-6 rounded-2xl bg-[#e7edf3] dark:bg-[#1c2632] border-none text-lg placeholder:text-[#94a3b8] focus:ring-2 focus:ring-primary/50 transition-all font-medium ios-input-shadow"
                            autoFocus
                        />
                        {error && (
                            <p className="text-red-500 text-sm ml-1 animate-in slide-in-from-top-1 fade-in">
                                {error}
                            </p>
                        )}
                    </div>

                    <div className="pt-2">
                        <button
                            onClick={handleContinue}
                            disabled={loading || !schoolCode}
                            className={`
                                w-full h-14 rounded-2xl bg-primary text-white text-lg font-bold tracking-wide shadow-lg shadow-primary/25 
                                flex items-center justify-center gap-2 transition-all active:scale-[0.98]
                                ${loading || !schoolCode ? 'opacity-70 cursor-not-allowed' : 'hover:bg-primary/90'}
                            `}
                        >
                            {loading ? (
                                <span className="material-symbols-outlined animate-spin">progress_activity</span>
                            ) : (
                                <span>Continue</span>
                            )}
                        </button>
                    </div>

                    <div className="flex justify-center pt-2">
                        <button
                            onClick={handleScanQR}
                            className="flex items-center gap-2 text-primary font-semibold py-2 px-4 rounded-xl hover:bg-primary/5 active:bg-primary/10 transition-colors"
                        >
                            <span className="material-symbols-outlined">qr_code_scanner</span>
                            <span>Scan QR Code</span>
                        </button>
                    </div>
                </div>

                {/* Platform Admin Link */}
                <div className="mt-8 flex justify-center">
                    <button
                        onClick={handleAdminLogin}
                        className="text-sm text-gray-400 dark:text-gray-500 hover:text-primary transition-colors flex items-center gap-1"
                    >
                        <span className="material-symbols-outlined text-base">admin_panel_settings</span>
                        Platform Admin
                    </button>
                </div>

                {/* Footer */}
                <div className="mt-auto pt-10 flex flex-col items-center gap-6">
                    <div className="w-12 h-1 bg-gray-200 dark:bg-gray-800 rounded-full" />

                    <div className="flex flex-col items-center gap-2">
                        <p className="text-[10px] items-center text-gray-400 dark:text-gray-600 font-bold uppercase tracking-[0.2em]">
                            {appVersion} • {appEnv} • © {currentYear}
                        </p>
                        <div className="flex items-center gap-4 text-xs font-semibold text-gray-400 dark:text-gray-500 tracking-wider uppercase">
                            <a href="/privacy" className="hover:text-primary transition-colors">Privacy</a>
                            <span className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-700" />
                            <a href="/terms" className="hover:text-primary transition-colors">Terms</a>
                        </div>
                    </div>
                </div>
            </div>

            {/* Help Popup */}
            <HelpPopup isOpen={showHelp} onClose={() => setShowHelp(false)} />
        </div>
    )
}
