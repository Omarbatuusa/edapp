export interface Tenant {
    id: string;
    name: string;
    code: string;
    logoUrl?: string;
    logo?: string;
    domain?: string;
    themeColor?: string;
}

export const MOCK_TENANTS: Tenant[] = [
    {
        id: "tenant_1",
        name: "St. Marks High School",
        code: "STMARKS",
        logoUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBHWulANizLBV6h9lghmURJjM6_161HnhmMjP18F87W02xV5ryaMfNhmFNFOFmSg40upRtGF01ZSTllJT8TVbwuNVQfXROfsLVKOUjM88JKn5dc0kMJEGwjElqV2SOO5LA6Er8FzhWCe2Ry-eWf_VF2RYwdv7Qk-vTcT6hjgjWdSWrT_6Nc5A444aARrS5sfEFWamwlJQ5lREA5vXTrDn3dEPLi5IeJa0XE4GUyKEjd9W_TrFMX1NG7xEKhsaoTAtziW6827PvL5Po",
        themeColor: "#135bec",
    },
    {
        id: "tenant_2",
        name: "Greenwood Primary",
        code: "GREENWOOD",
        themeColor: "#10b981",
    },
];

export async function searchTenant(code: string): Promise<Tenant | null> {
    return new Promise((resolve) => {
        setTimeout(() => {
            const tenant = MOCK_TENANTS.find((t) => t.code.toLowerCase() === code.toLowerCase());
            resolve(tenant || null);
        }, 800); // Simulate network delay
    });
}
