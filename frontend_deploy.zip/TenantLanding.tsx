import { useState, useEffect } from 'react';
import RoleSelection, { type UserRole } from './RoleSelection';
import LoginForm from './LoginForm';
import ParentDashboard from './ParentDashboard';
import CommunicationHub from './CommunicationHub';
import HomeworkAssignments from './HomeworkAssignments';
import EmergencyAlert from './EmergencyAlert';
import SilentHelp from './SilentHelp';
import UserProfile from './UserProfile';
import { type Tenant } from '../utils/mockData';

type Step = 'role' | 'login' | 'dashboard' | 'hub' | 'assignments' | 'profile';

export default function TenantLanding() {
    const [step, setStep] = useState<Step>('role');
    const [role, setRole] = useState<UserRole | null>(null);

    // Mock Tenant Data (Simulating resolution from hostname)
    const [tenant] = useState<Tenant>({
        id: '1',
        name: 'Spark Schools - Ormonde',
        logo: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDbSWYFcETC0O_5OgHCiN1DHzARoUO9MnysMJiefE0q1aazYLcchg0fr_uc6p2Iarn32WECQuZDcwzxWlRPZzVmMl_Pq2W6ltU8JgJ5DNQjXaprJGXcr9mywFs0AFxg19nXWCZsV5VqayvHlpjk6ytdNanD1VDiujrDS2dkP5XJcp1MIZ2JMKn_lvuZS36h6fpX7qz9eIJqs-lz6dcKeu__X46_lXut-3IP_gH4SWNGQ4k_bpsLn1iAkVopG_UbPcOg1735Q_KOLl8',
        domain: 'spark-ormonde.edapp.co.za'
    });

    // Overlay states
    const [showEmergency, setShowEmergency] = useState(false);
    const [showSilentHelp, setShowSilentHelp] = useState(false);

    const handleRoleSelect = (selectedRole: UserRole) => {
        setRole(selectedRole);
        setStep('login');
    };

    const handleBackToRole = () => {
        setStep('role');
        setRole(null);
    };

    const handleLoginSuccess = () => {
        setStep('dashboard');
    };

    const handleOpenHub = () => setStep('hub');
    const handleOpenAssignments = () => setStep('assignments');
    const handleOpenProfile = () => setStep('profile');
    const handleOpenEmergency = () => setShowEmergency(true);
    const handleOpenSilentHelp = () => setShowSilentHelp(true);
    const handleBackToDashboard = () => setStep('dashboard');

    const handleLogout = () => {
        setStep('role');
        setRole(null);
    };

    // Main Render Flow matches original App.tsx logic minus Search
    if (step === 'dashboard' || step === 'hub' || step === 'assignments' || step === 'profile') {
        return (
            <>
                <ParentDashboard
                    onOpenHub={handleOpenHub}
                    onOpenAssignments={handleOpenAssignments}
                    onOpenEmergency={handleOpenEmergency}
                    onOpenSilentHelp={handleOpenSilentHelp}
                    onOpenProfile={handleOpenProfile}
                />

                {/* Stacked Pages */}
                <div className={`fixed inset-0 z-50 overflow-y-auto bg-background-light dark:bg-background-dark transition-transform duration-300 ease-in-out ${step === 'hub' ? 'translate-x-0' : 'translate-x-full'}`}>
                    <CommunicationHub onBack={handleBackToDashboard} />
                </div>
                <div className={`fixed inset-0 z-50 overflow-y-auto bg-background-light dark:bg-background-dark transition-transform duration-300 ease-in-out ${step === 'assignments' ? 'translate-x-0' : 'translate-x-full'}`}>
                    <HomeworkAssignments onBack={handleBackToDashboard} />
                </div>
                <div className={`fixed inset-0 z-50 overflow-y-auto bg-background-light dark:bg-background-dark transition-transform duration-300 ease-in-out ${step === 'profile' ? 'translate-x-0' : 'translate-x-full'}`}>
                    <UserProfile onBack={handleBackToDashboard} onLogout={handleLogout} />
                </div>

                {/* Overlays */}
                {showEmergency && <EmergencyAlert onDismiss={() => setShowEmergency(false)} />}
                {showSilentHelp && <SilentHelp onDismiss={() => setShowSilentHelp(false)} />}
            </>
        );
    }

    return (
        <main className="flex-1 flex flex-col w-full max-w-md mx-auto px-4 py-6 justify-center min-h-screen">
            {step === 'role' && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="mb-4 text-center">
                        <p className="text-sm text-primary font-medium bg-primary/10 inline-block px-3 py-1 rounded-full">
                            {tenant.name}
                        </p>
                    </div>
                    <RoleSelection onRoleSelect={handleRoleSelect} />
                </div>
            )}

            {step === 'login' && role && (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <LoginForm
                        role={role}
                        schoolName={tenant.name}
                        onBack={handleBackToRole}
                        onLoginSuccess={handleLoginSuccess}
                    />
                </div>
            )}
        </main>
    );
}
