import TenantSearch from './TenantSearch';
import { type Tenant } from '../utils/mockData';

export default function PlatformSearch() {
    const handleTenantFound = (tenant: Tenant) => {
        // In a real app, this would redirect to {tenant.slug}.edapp.co.za
        alert(`Redirecting to ${tenant.name} portal...`);
        // window.location.href = `https://${tenant.slug}.edapp.co.za`; 
    };

    return (
        <div className="min-h-screen bg-background-light dark:bg-background-dark flex items-center justify-center p-4">
            <div className="w-full max-w-md">
                <h1 className="text-center text-2xl font-bold mb-8 dark:text-white">Find Your School</h1>
                <TenantSearch onTenantFound={handleTenantFound} />
            </div>
        </div>
    );
}
