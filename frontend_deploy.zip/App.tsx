import PlatformSearch from "./components/PlatformSearch";
import TenantLanding from "./components/TenantLanding";
import ApplyLanding from "./components/ApplyLanding";

function classifyHost(hostname: string) {
  const h = (hostname || "").toLowerCase().trim();

  // Apply domains: apply-ormonde.edapp.co.za, apply-xyz.edapp.co.za
  if (h.startsWith("apply-")) return "apply";

  // Platform domains
  if (h === "edapp.co.za" || h === "www.edapp.co.za" || h === "localhost" || h === "127.0.0.1") {
    // Note: Localhost usually acts as "Platform" for dev, but if we want to test Tenant view locally we might need to change this return or use hosts file.
    // For now, adhering to user prompt: localhost = platform.
    return "platform";
  }

  // Everything else is a tenant domain
  return "tenant";
}

export default function App() {
  const mode = classifyHost(window.location.hostname);

  if (mode === "apply") return <ApplyLanding />;
  if (mode === "platform") return <PlatformSearch />;
  return <TenantLanding />;
}
