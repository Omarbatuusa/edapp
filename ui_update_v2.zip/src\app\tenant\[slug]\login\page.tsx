'use client'

import { useState, useEffect } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Shield, Users, UserCircle, GraduationCap } from 'lucide-react'

const roles = [
    {
        id: 'admin',
        title: 'Admin',
        subtitle: 'School administrators',
        icon: Shield,
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        borderColor: 'border-red-600'
    },
    {
        id: 'staff',
        title: 'Staff',
        subtitle: 'Teachers and staff members',
        icon: Users,
        color: 'text-blue-600',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-600'
    },
    {
        id: 'parent',
        title: 'Parent/Guardian',
        subtitle: 'Parents and guardians',
        icon: UserCircle,
        color: 'text-green-600',
        bgColor: 'bg-green-50',
        borderColor: 'border-green-600'
    },
    {
        id: 'learner',
        title: 'Learner',
        subtitle: 'Students',
        icon: GraduationCap,
        color: 'text-purple-600',
        bgColor: 'bg-purple-50',
        borderColor: 'border-purple-600'
    }
]

export default function TenantLoginPage() {
    const router = useRouter()
    const params = useParams()
    const tenantSlug = params.slug as string
    const [selectedRole, setSelectedRole] = useState<string | null>(null)
    const [lastRole, setLastRole] = useState<string | null>(null)

    // Load last role from localStorage
    useEffect(() => {
        const stored = localStorage.getItem(`last_role_${tenantSlug}`)
        if (stored) {
            setLastRole(stored)
        }
    }, [tenantSlug])

    const handleRoleSelect = (roleId: string) => {
        // Save last role
        localStorage.setItem(`last_role_${tenantSlug}`, roleId)

        // Navigate to role-specific login
        router.push(`/tenant/${tenantSlug}/login/${roleId}`)
    }

    return (
        <div className="app-page">
            <div className="app-container">
                <div className="flex flex-col items-center justify-center min-h-screen py-8">
                    {/* Header */}
                    <div className="mb-8 text-center">
                        <h1 className="text-3xl font-bold mb-2">Welcome Back</h1>
                        <p className="text-muted-foreground">Select your role to continue</p>
                    </div>

                    {/* Role Cards Grid */}
                    <div className="w-full max-w-2xl grid grid-cols-1 md:grid-cols-2 gap-4">
                        {roles.map((role) => {
                            const Icon = role.icon
                            const isLastRole = lastRole === role.id
                            const isSelected = selectedRole === role.id

                            return (
                                <Card
                                    key={role.id}
                                    className={`
                                        cursor-pointer transition-all duration-200 
                                        hover:shadow-lg
                                        ${isSelected ? 'ring-2 ring-primary' : ''}
                                        ${isLastRole ? 'border-2 border-primary/50' : ''}
                                    `}
                                    onClick={() => handleRoleSelect(role.id)}
                                    onMouseEnter={() => setSelectedRole(role.id)}
                                    onMouseLeave={() => setSelectedRole(null)}
                                >
                                    <CardContent className="p-6">
                                        <div className="flex flex-col items-center text-center space-y-4">
                                            {/* Icon */}
                                            <div className={`
                                                w-16 h-16 rounded-full flex items-center justify-center
                                                ${role.bgColor}
                                            `}>
                                                <Icon className={`h-8 w-8 ${role.color}`} />
                                            </div>

                                            {/* Title */}
                                            <div>
                                                <h3 className="text-xl font-bold mb-1">
                                                    {role.title}
                                                </h3>
                                                <p className="text-sm text-muted-foreground">
                                                    {role.subtitle}
                                                </p>
                                            </div>

                                            {/* Last Role Badge */}
                                            {isLastRole && (
                                                <div className="text-xs text-primary font-medium">
                                                    Last used
                                                </div>
                                            )}
                                        </div>
                                    </CardContent>
                                </Card>
                            )
                        })}
                    </div>

                    {/* Footer */}
                    <div className="mt-8 text-center">
                        <p className="text-sm text-muted-foreground mb-2">
                            Not a current learner or parent?
                        </p>
                        <a
                            href={`https://apply-${tenantSlug}.edapp.co.za`}
                            className="text-primary hover:underline font-medium"
                        >
                            Apply Now →
                        </a>
                    </div>
                </div>
            </div>
        </div>
    )
}
