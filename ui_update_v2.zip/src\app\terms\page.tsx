export default function TermsPage() {
    return (
        <div className="min-h-screen bg-[#f6f7f8] dark:bg-[#101922] text-[#0d141b] dark:text-white p-8 animate-in fade-in">
            <div className="max-w-2xl mx-auto space-y-8">
                <header>
                    <h1 className="text-3xl font-bold font-display mb-2">Terms of Use</h1>
                    <p className="text-gray-500">Last updated: January 2026</p>
                </header>

                <section className="space-y-4 text-gray-600 dark:text-gray-300 leading-relaxed">
                    <p>
                        By using EdApp, you agree to these Terms of Use. Please read them carefully.
                    </p>
                    <div className="h-32 bg-gray-200 dark:bg-gray-800 rounded-xl flex items-center justify-center text-gray-400 text-sm">
                        [Content Placeholder: User Agreement]
                    </div>
                    <div className="h-32 bg-gray-200 dark:bg-gray-800 rounded-xl flex items-center justify-center text-gray-400 text-sm">
                        [Content Placeholder: Acceptable Use]
                    </div>
                </section>

                <footer className="pt-8 border-t border-gray-200 dark:border-gray-800">
                    <a href="/discovery" className="text-primary hover:underline font-medium">
                        ← Back to App
                    </a>
                </footer>
            </div>
        </div>
    )
}
