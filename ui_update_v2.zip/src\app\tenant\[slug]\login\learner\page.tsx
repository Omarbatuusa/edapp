'use client'

import { useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { GraduationCap, ArrowLeft, HelpCircle } from 'lucide-react'

export default function LearnerLoginPage() {
    const router = useRouter()
    const params = useParams()
    const tenantSlug = params.slug as string

    const [studentNumber, setStudentNumber] = useState('')
    const [pin, setPin] = useState('')
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState('')
    const [attempts, setAttempts] = useState(0)

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)
        setError('')

        try {
            const response = await fetch('/api/v1/auth/learner/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    studentNumber,
                    pin,
                    tenantSlug
                })
            })

            if (!response.ok) {
                const data = await response.json()
                throw new Error(data.message || 'Invalid credentials')
            }

            const { customToken } = await response.json()

            // Sign in with custom token
            // TODO: Implement Firebase custom token sign-in

            // Redirect to learner dashboard
            router.push(`/tenant/${tenantSlug}/dashboard`)
        } catch (err: any) {
            setError(err.message)
            setAttempts(prev => prev + 1)
        } finally {
            setLoading(false)
        }
    }

    const handleBack = () => {
        router.push(`/tenant/${tenantSlug}/login`)
    }

    const handleNeedHelp = () => {
        // TODO: Show help dialog or redirect to help page
        alert('Please contact your school administrator for assistance.')
    }

    return (
        <div className="app-page">
            <div className="app-container">
                <div className="flex flex-col items-center justify-center min-h-screen py-8">
                    {/* Back Button */}
                    <Button
                        variant="ghost"
                        onClick={handleBack}
                        className="self-start mb-4"
                    >
                        <ArrowLeft className="mr-2 h-4 w-4" />
                        Back
                    </Button>

                    {/* Login Card */}
                    <Card className="w-full max-w-md card-elevated">
                        <CardHeader className="text-center">
                            <div className="flex justify-center mb-4">
                                <div className="w-16 h-16 rounded-full bg-purple-50 flex items-center justify-center">
                                    <GraduationCap className="h-8 w-8 text-purple-600" />
                                </div>
                            </div>
                            <CardTitle className="text-2xl">Learner Login</CardTitle>
                            <p className="text-sm text-muted-foreground">
                                Enter your student number and PIN
                            </p>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleLogin} className="space-y-4">
                                {/* Student Number */}
                                <div className="space-y-2">
                                    <Label htmlFor="studentNumber">Student Number</Label>
                                    <Input
                                        id="studentNumber"
                                        type="text"
                                        placeholder="e.g., 2024001"
                                        value={studentNumber}
                                        onChange={(e) => setStudentNumber(e.target.value)}
                                        className="text-center font-mono"
                                        maxLength={10}
                                        required
                                        autoFocus
                                    />
                                </div>

                                {/* PIN */}
                                <div className="space-y-2">
                                    <Label htmlFor="pin">PIN</Label>
                                    <Input
                                        id="pin"
                                        type="password"
                                        placeholder="Enter your PIN"
                                        value={pin}
                                        onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                                        className="text-center font-mono text-2xl tracking-widest"
                                        maxLength={6}
                                        required
                                    />
                                    <p className="text-xs text-muted-foreground text-center">
                                        4-6 digit PIN
                                    </p>
                                </div>

                                {/* Error Message */}
                                {error && (
                                    <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                                        <p className="text-sm text-red-600">{error}</p>
                                    </div>
                                )}

                                {/* Sign In Button */}
                                <Button
                                    type="submit"
                                    className="w-full btn-outline-effect"
                                    size="lg"
                                    disabled={loading || !studentNumber || pin.length < 4}
                                >
                                    {loading ? 'Signing in...' : 'Sign In'}
                                </Button>

                                {/* Need Help */}
                                <Button
                                    type="button"
                                    variant="ghost"
                                    className="w-full"
                                    onClick={handleNeedHelp}
                                >
                                    <HelpCircle className="mr-2 h-4 w-4" />
                                    Need help?
                                </Button>
                            </form>
                        </CardContent>
                    </Card>

                    {/* Security Notice */}
                    {attempts >= 3 && (
                        <div className="mt-4 text-center text-sm text-muted-foreground">
                            <p>Multiple failed attempts detected.</p>
                            <p>Please contact your school if you've forgotten your PIN.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
