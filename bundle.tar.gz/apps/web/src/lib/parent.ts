'use client';

// ============================================================
// PARENT DASHBOARD TYPES & MOCK DATA
// ============================================================

// Child Types
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'off-campus' | 'unknown';

export interface Child {
    id: string;
    name: string;
    avatar?: string;
    grade: string;
    class: string;
    branch?: string;
    status: AttendanceStatus;
    lastSeen?: {
        location: string;
        time: string;
    };
    needsVerification?: boolean;
}

// Homework Types
export interface Homework {
    id: string;
    title: string;
    subject: string;
    childId: string;
    childName: string;
    dueDate: string;
    dueBadge: 'today' | 'tomorrow' | 'this-week' | 'overdue';
    icon: string;
    status: 'pending' | 'submitted' | 'graded';
}

// Announcement Types
export interface Announcement {
    id: string;
    title: string;
    preview: string;
    postedAt: string;
    requiresAcknowledge: boolean;
    acknowledged?: boolean;
    priority: 'normal' | 'high' | 'urgent';
    attachments?: number;
}

// School Life Post Types
export interface SchoolPost {
    id: string;
    author: {
        name: string;
        avatar?: string;
        department?: string;
    };
    content: string;
    image?: string;
    postedAt: string;
    likes: number;
    comments: number;
    liked?: boolean;
}

// Quick Action Types
export interface QuickAction {
    id: string;
    label: string;
    icon: string;
    href: string;
    primary?: boolean;
    badge?: number;
}

// Fees Types
export interface FeesBalance {
    totalDue: number;
    dueDate: string;
    currency: string;
    children: {
        childId: string;
        childName: string;
        amount: number;
    }[];
}

export interface Payment {
    id: string;
    amount: number;
    currency: string;
    date: string;
    method: string;
    reference: string;
    status: 'completed' | 'pending' | 'failed';
}

// Chat/Thread Types
export interface ChatThread {
    id: string;
    type: 'dm' | 'channel' | 'support' | 'safeguarding';
    name: string;
    avatar?: string;
    context?: string;
    lastMessage: string;
    lastMessageTime: string;
    unreadCount: number;
    urgent?: boolean;
    category?: 'fees' | 'admissions' | 'transport' | 'it' | 'general';
    status?: 'open' | 'pending' | 'closed';
}

export interface ChatMessage {
    id: string;
    threadId: string;
    senderId: string;
    senderName: string;
    senderAvatar?: string;
    content: string;
    attachments?: { name: string; url: string; type: string }[];
    isOwn: boolean;
    timestamp: string;
    status: 'sending' | 'sent' | 'delivered' | 'read';
}

export interface ChatAnnouncement {
    id: string;
    title: string;
    preview: string;
    time: string;
    badges: ('urgent' | 'ack' | 'doc' | 'event')[];
    requiresAck: boolean;
    acknowledged: boolean;
}

// ============================================================
// MOCK DATA
// ============================================================

export const MOCK_CHILDREN: Child[] = [
    {
        id: 'child-1',
        name: 'Bart Simpson',
        avatar: 'https://ui-avatars.com/api/?name=Bart+S&background=6366f1&color=fff&size=128',
        grade: 'Grade 4',
        class: 'Ormonde Campus',
        status: 'present',
        lastSeen: {
            location: 'Gate 1',
            time: '07:45 AM',
        },
    },
    {
        id: 'child-2',
        name: 'Lisa Simpson',
        avatar: 'https://ui-avatars.com/api/?name=Lisa+S&background=ec4899&color=fff&size=128',
        grade: 'Grade 6',
        class: 'Ormonde Campus',
        status: 'present',
        lastSeen: {
            location: 'Library',
            time: '08:15 AM',
        },
    },
];

export const MOCK_HOMEWORK: Homework[] = [
    {
        id: 'hw-1',
        title: 'Maths Worksheet',
        subject: 'Ch 4. Algebra',
        childId: 'child-1',
        childName: 'Bart Simpson',
        dueDate: '2026-02-06',
        dueBadge: 'tomorrow',
        icon: 'calculate',
        status: 'pending',
    },
    {
        id: 'hw-2',
        title: 'English Essay',
        subject: 'Creative Writing',
        childId: 'child-2',
        childName: 'Lisa Simpson',
        dueDate: '2026-02-07',
        dueBadge: 'this-week',
        icon: 'edit_note',
        status: 'pending',
    },
];

export const MOCK_ANNOUNCEMENTS: Announcement[] = [
    {
        id: 'ann-1',
        title: 'Early Closure on Friday',
        preview: 'School closes at 12:00 PM for Staff Development. Please arrange transport.',
        postedAt: '2 hours ago',
        requiresAcknowledge: true,
        acknowledged: false,
        priority: 'high',
    },
    {
        id: 'ann-2',
        title: 'Term 1 Fee Reminder',
        preview: 'Outstanding fees must be settled by 10 February to avoid late payment charges.',
        postedAt: '1 day ago',
        requiresAcknowledge: false,
        priority: 'normal',
    },
    {
        id: 'ann-3',
        title: 'Sports Day Registration',
        preview: 'Register your child for Sports Day events by Friday. Forms available at reception.',
        postedAt: '2 days ago',
        requiresAcknowledge: false,
        priority: 'normal',
        attachments: 1,
    },
];

export const MOCK_SCHOOL_POSTS: SchoolPost[] = [
    {
        id: 'post-1',
        author: {
            name: 'Lakewood Academy',
            avatar: 'https://ui-avatars.com/api/?name=LIA&background=0ea5e9&color=fff',
            department: 'Sports Dept',
        },
        content: 'Our soccer team dominated the inter-school tournament! 🏆 Great teamwork and dedication from all players. #LakewoodPride #Soccer',
        image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=600&h=400&fit=crop',
        postedAt: '4h ago',
        likes: 124,
        comments: 8,
        liked: false,
    },
    {
        id: 'post-2',
        author: {
            name: 'Music Department',
            avatar: 'https://ui-avatars.com/api/?name=MD&background=8b5cf6&color=fff',
            department: 'Arts',
        },
        content: 'Our choir performed beautifully at the Regional Music Festival. Special congratulations to the soloists! 🎵',
        image: 'https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=600&h=400&fit=crop',
        postedAt: '1d ago',
        likes: 89,
        comments: 12,
        liked: true,
    },
];

export const PARENT_QUICK_ACTIONS: QuickAction[] = [
    { id: 'pay', label: 'Pay Fees', icon: 'payments', href: '/pay', primary: true },
    { id: 'message', label: 'Message', icon: 'chat', href: '/chat' },
    { id: 'absence', label: 'Report Absence', icon: 'event_busy', href: '/report-absence' },
    { id: 'calendar', label: 'Calendar', icon: 'calendar_month', href: '/calendar' },
];

// ============================================================
// HELPER FUNCTIONS
// ============================================================

export function getStatusColor(status: AttendanceStatus): string {
    switch (status) {
        case 'present': return 'bg-emerald-500';
        case 'absent': return 'bg-red-500';
        case 'late': return 'bg-amber-500';
        case 'off-campus': return 'bg-blue-500';
        default: return 'bg-gray-400';
    }
}

export function getStatusLabel(status: AttendanceStatus): string {
    switch (status) {
        case 'present': return 'Present';
        case 'absent': return 'Absent';
        case 'late': return 'Late';
        case 'off-campus': return 'Off-campus';
        default: return 'Unknown';
    }
}

export function getDueBadgeStyle(badge: Homework['dueBadge']): { bg: string; text: string; label: string } {
    switch (badge) {
        case 'today': return { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-600 dark:text-red-400', label: 'TODAY' };
        case 'tomorrow': return { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-600 dark:text-amber-400', label: 'TOMORROW' };
        case 'this-week': return { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-600 dark:text-blue-400', label: 'FRIDAY' };
        case 'overdue': return { bg: 'bg-red-500', text: 'text-white', label: 'OVERDUE' };
    }
}

// ============================================================
// FEES MOCK DATA
// ============================================================

export const MOCK_FEES_BALANCE: FeesBalance = {
    totalDue: 12500,
    dueDate: '10 February 2026',
    currency: 'ZAR',
    children: [
        { childId: 'child-1', childName: 'Bart Simpson', amount: 6500 },
        { childId: 'child-2', childName: 'Lisa Simpson', amount: 6000 },
    ],
};

export const MOCK_PAYMENTS: Payment[] = [
    {
        id: 'pay-1',
        amount: 5000,
        currency: 'ZAR',
        date: '2026-01-15',
        method: 'Card',
        reference: 'PAY-2026-0001',
        status: 'completed',
    },
    {
        id: 'pay-2',
        amount: 3500,
        currency: 'ZAR',
        date: '2025-12-20',
        method: 'EFT',
        reference: 'PAY-2025-0089',
        status: 'completed',
    },
];

export function formatCurrency(amount: number, currency: string = 'ZAR'): string {
    return new Intl.NumberFormat('en-ZA', {
        style: 'currency',
        currency: currency,
        minimumFractionDigits: 0,
    }).format(amount);
}

// ============================================================
// CHAT MOCK DATA
// ============================================================

export const MOCK_CHAT_THREADS: ChatThread[] = [
    {
        id: 'thread-1',
        type: 'dm',
        name: 'Mrs. Smith',
        avatar: 'MS',
        context: 'Class Teacher',
        lastMessage: 'Thank you for the update! Bart is doing much better in class now.',
        lastMessageTime: '10:30 AM',
        unreadCount: 2,
        urgent: false,
    },
    {
        id: 'thread-2',
        type: 'dm',
        name: 'Admin Office',
        avatar: 'AO',
        context: 'Administration',
        lastMessage: 'Your payment of R5,000 has been received and processed.',
        lastMessageTime: 'Yesterday',
        unreadCount: 0,
    },
    {
        id: 'thread-3',
        type: 'dm',
        name: 'Sports Department',
        avatar: 'SD',
        context: 'Extra-murals',
        lastMessage: 'Soccer practice moved to 3pm this Friday due to weather.',
        lastMessageTime: 'Mon',
        unreadCount: 0,
    },
    {
        id: 'thread-4',
        type: 'dm',
        name: 'Mr. Johnson',
        avatar: 'MJ',
        context: 'Grade Head',
        lastMessage: 'Please contact me regarding Lisa\'s science project.',
        lastMessageTime: 'Tue',
        unreadCount: 1,
        urgent: true,
    },
];

export const MOCK_CHAT_ANNOUNCEMENTS: ChatAnnouncement[] = [
    {
        id: 'ann-1',
        title: 'Early Closure on Friday',
        preview: 'School closes at 12:00 PM this Friday for staff development.',
        time: '2h ago',
        badges: ['urgent', 'ack'],
        requiresAck: true,
        acknowledged: false,
    },
    {
        id: 'ann-2',
        title: 'Term 1 Calendar Published',
        preview: 'Please review the updated Term 1 calendar with all important dates.',
        time: 'Yesterday',
        badges: ['doc'],
        requiresAck: false,
        acknowledged: false,
    },
    {
        id: 'ann-3',
        title: 'Parent-Teacher Meetings',
        preview: 'Book your slot for parent-teacher meetings next week.',
        time: '3d ago',
        badges: ['event', 'ack'],
        requiresAck: true,
        acknowledged: true,
    },
];

export const MOCK_SUPPORT_TICKETS: ChatThread[] = [
    {
        id: 'ticket-1',
        type: 'support',
        name: 'Fees Query',
        category: 'fees',
        lastMessage: 'I have a question about the payment plan options.',
        lastMessageTime: '1d ago',
        unreadCount: 0,
        status: 'pending',
    },
    {
        id: 'ticket-2',
        type: 'support',
        name: 'Transport Route Change',
        category: 'transport',
        lastMessage: 'We need to update our pickup address.',
        lastMessageTime: '3d ago',
        unreadCount: 1,
        status: 'open',
    },
];


