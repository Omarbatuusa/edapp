const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');

router.get('/search', studentController.searchStudents);

module.exports = router;
